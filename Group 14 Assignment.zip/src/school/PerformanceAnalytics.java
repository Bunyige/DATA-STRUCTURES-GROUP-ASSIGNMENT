package school;

import java.util.*;

public class PerformanceAnalytics {
    private Map<String, Integer> scores = new HashMap<>();

    public void addScore(String studentId, int score) {
        scores.put(studentId, scores.getOrDefault(studentId, 0) + score);
    }

    public void topStudents(int k) {
        scores.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(k)
                .forEach(e -> System.out.println(e.getKey() + ": " + e.getValue()));
    }
}
