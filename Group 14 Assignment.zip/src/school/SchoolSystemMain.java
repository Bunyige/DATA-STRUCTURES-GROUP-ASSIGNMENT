package school;

public class SchoolSystemMain {
    public static void main(String[] args) {
        // Student registry
        StudentRegistry registry = new StudentRegistry();
        registry.addStudent(new Student("S001", "Alice", "alice@example.edu"));
        registry.addStudent(new Student("S002", "Bob", "bob@example.edu"));

        // Course enrollment
        Course c = new Course("C101", "Data Structures", 1);
        System.out.println("Enroll S001: " + c.enroll("S001"));
        System.out.println("Enroll S002: " + c.enroll("S002"));
        c.processWaitlist();
        System.out.println(c);

        // Fee tracker
        FeeTracker fees = new FeeTracker();
        fees.addPayment("2025-09-01", 500.0);
        fees.addPayment("2025-09-02", 450.0);
        fees.printPayments();

        // Library system
        LibrarySystem lib = new LibrarySystem();
        lib.addBook("ISBN001", 2);
        System.out.println("Borrow S001: " + lib.borrow("ISBN001"));
        System.out.println("Undo last: " + lib.undoLast());

        // Performance analytics
        PerformanceAnalytics analytics = new PerformanceAnalytics();
        analytics.addScore("S001", 88);
        analytics.addScore("S002", 92);
        System.out.println("Top Students:");
        analytics.topStudents(2);
    }
}
