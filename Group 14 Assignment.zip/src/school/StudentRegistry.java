package school;

import java.util.HashMap;
import java.util.Map;

public class StudentRegistry {
    private Map<String, Student> students = new HashMap<>();

    public boolean addStudent(Student s) {
        if (students.containsKey(s.getId())) return false;
        students.put(s.getId(), s);
        return true;
    }

    public Student getStudent(String id) {
        return students.get(id);
    }

    public boolean removeStudent(String id) {
        return students.remove(id) != null;
    }
}
