# Design Document — Group One Assignment

See code in `src/school/`. This Java implementation maps modules to data structures:
- StudentRegistry: HashMap
- Course: LinkedList + Queue
- FeeTracker: TreeMap (sorted)
- LibrarySystem: HashMap + Stack
- PerformanceAnalytics: HashMap + sorting for top-k
