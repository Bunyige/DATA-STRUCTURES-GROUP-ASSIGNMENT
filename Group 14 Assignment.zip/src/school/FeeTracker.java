package school;

import java.util.Map;
import java.util.TreeMap;

public class FeeTracker {
    private Map<String, Double> payments = new TreeMap<>();

    public void addPayment(String date, double amount) {
        payments.put(date, amount);
    }

    public void printPayments() {
        for (Map.Entry<String, Double> entry : payments.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }
    }
}
