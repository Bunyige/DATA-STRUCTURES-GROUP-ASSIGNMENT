package school;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class LibrarySystem {
    private Map<String, Integer> catalog = new HashMap<>();
    private Stack<String> actions = new Stack<>();

    public void addBook(String isbn, int copies) {
        catalog.put(isbn, catalog.getOrDefault(isbn, 0) + copies);
    }

    public boolean borrow(String isbn) {
        int count = catalog.getOrDefault(isbn, 0);
        if (count <= 0) return false;
        catalog.put(isbn, count - 1);
        actions.push("borrow:" + isbn);
        return true;
    }

    public boolean undoLast() {
        if (actions.isEmpty()) return false;
        String act = actions.pop();
        if (act.startsWith("borrow:")) {
            String isbn = act.split(":")[1];
            catalog.put(isbn, catalog.getOrDefault(isbn, 0) + 1);
        }
        return true;
    }
}
