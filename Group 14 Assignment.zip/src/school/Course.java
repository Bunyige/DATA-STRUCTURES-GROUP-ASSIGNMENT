package school;

import java.util.LinkedList;
import java.util.Queue;

public class Course {
    private String id;
    private String name;
    private int capacity;
    private LinkedList<String> enrolled = new LinkedList<>();
    private Queue<String> waitlist = new LinkedList<>();

    public Course(String id, String name, int capacity) {
        this.id = id;
        this.name = name;
        this.capacity = capacity;
    }

    public String enroll(String studentId) {
        if (enrolled.size() < capacity) {
            enrolled.add(studentId);
            return "enrolled";
        } else {
            waitlist.add(studentId);
            return "waitlisted";
        }
    }

    public void processWaitlist() {
        while (enrolled.size() < capacity && !waitlist.isEmpty()) {
            enrolled.add(waitlist.poll());
        }
    }

    @Override
    public String toString() {
        return "Course{id='" + id + "', name='" + name + "', enrolled=" + enrolled + ", waitlist=" + waitlist + "}";
    }
}
